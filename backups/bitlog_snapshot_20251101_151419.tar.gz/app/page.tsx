// [BLOQUE 1] Home "/"
export default function Page() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Bitlog 2.0</h1>
      <p>Deploy OK. Si ves esto, ya no hay 404.</p>
    </main>
  );
}

