// [BLOQUE 1] Server component
import { supabaseAdmin } from "@/lib/supabaseAdmin";

// [BLOQUE 2] Carga server-side (primer page load)
async function getTrades(limit = 50) {
  // Nota: simplificado: orden por dt_open_utc desc, id desc
  const { data, error } = await supabaseAdmin
    .from("trades")
    .select("id, ticket, symbol, side, dt_open_utc, dt_close_utc, pnl_usd_net, ea, session")
    .order("dt_open_utc", { ascending: false })
    .order("id", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data ?? [];
}

// [BLOQUE 3] Render
export default async function TradesPage() {
  const rows = await getTrades();

  return (
    <main className="p-6 max-w-5xl mx-auto">
      <h1 className="text-xl font-semibold mb-4">Trades</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {rows.map((r) => {
          const pnl = Number(r.pnl_usd_net ?? 0);
          const pnlClass = pnl >= 0 ? "text-green-700" : "text-red-700";
          return (
            <a
              key={r.id}
              href={`/trades/${r.id}`}
              className="border rounded p-3 hover:shadow-sm transition"
            >
              <div className="text-sm text-gray-500">#{r.id} · {r.ticket}</div>
              <div className="font-medium">{r.symbol} · {r.side}</div>
              <div className={`font-semibold ${pnlClass}`}>
                ${pnl.toFixed(2)}
              </div>
              <div className="text-xs text-gray-500">
                {r.ea ?? "—"} · {r.session ?? "—"}
              </div>
              <div className="text-xs text-gray-400">
                {new Date(r.dt_open_utc).toLocaleString("es-MX", { timeZone: "America/Mazatlan" })}
              </div>
            </a>
          );
        })}
      </div>
    </main>
  );
}

