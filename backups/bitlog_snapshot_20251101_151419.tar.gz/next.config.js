// [BLOQUE 1] Next config mínimo
/** @type {import('next').NextConfig} */
const nextConfig = {};
module.exports = nextConfig;

