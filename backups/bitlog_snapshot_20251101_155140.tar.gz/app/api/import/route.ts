// [BLOQUE 1] Config
export const runtime = "nodejs"; // en Vercel free OK

// [BLOQUE 2] POST handler
export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get("file") as File | null;
    if (!file) return Response.json({ ok: false, error: "Missing file" }, { status: 400 });

    // [BLOQUE 3] Reenvía a Edge Function con Service Role (server side)
    const efUrl = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/import_csv`;
    const r = await fetch(efUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY!}`,
      },
      body: form,
    });

    const j = await r.json().catch(() => ({}));
    if (!r.ok) return Response.json({ ok: false, status: r.status, j }, { status: 500 });

    return Response.json(j);
  } catch (e: any) {
    return Response.json({ ok: false, error: e?.message ?? "server error" }, { status: 500 });
  }
}

