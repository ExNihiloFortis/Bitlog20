// [BLOQUE 1] Server component param
import { supabaseAdmin } from "@/lib/supabaseAdmin";

async function getTrade(id: number) {
  const { data, error } = await supabaseAdmin
    .from("trades")
    .select("*")
    .eq("id", id)
    .single();
  if (error) throw error;
  return data;
}

export default async function TradeDetail({ params }: { params: { id: string } }) {
  const trade = await getTrade(Number(params.id));
  const pnl = Number(trade.pnl_usd_net ?? 0);
  const pnlClass = pnl >= 0 ? "text-green-700" : "text-red-700";
  const badge = pnl >= 0 ? "WINNER" : "LOSER";

  const hasClose = !!trade.dt_close_utc;
  const durationSec = hasClose
    ? Math.floor((new Date(trade.dt_close_utc).getTime() - new Date(trade.dt_open_utc).getTime()) / 1000)
    : null;

  return (
    <main className="p-6 max-w-3xl mx-auto">
      <h1 className="text-xl font-semibold mb-2">
        #{trade.id} · {trade.symbol} · {trade.side}
      </h1>

      <div className="mb-2">
        <span className={`px-2 py-1 text-xs rounded border ${pnl >= 0 ? "border-green-600 text-green-700" : "border-red-600 text-red-700"}`}>
          {badge}
        </span>
      </div>

      <div className="space-y-1 text-sm">
        <div><b>P&L neto:</b> <span className={pnlClass}>${pnl.toFixed(2)}</span></div>
        <div><b>EA:</b> {trade.ea ?? "—"} · <b>Sesión:</b> {trade.session ?? "—"} · <b>TF:</b> {trade.timeframe ?? "—"}</div>
        <div><b>Apertura:</b> {new Date(trade.dt_open_utc).toLocaleString("es-MX", { timeZone: "America/Mazatlan" })}</div>
        <div><b>Cierre:</b> {trade.dt_close_utc
          ? new Date(trade.dt_close_utc).toLocaleString("es-MX", { timeZone: "America/Mazatlan" })
          : "—"}</div>
        <div><b>Duración:</b> {durationSec !== null ? new Date(durationSec * 1000).toISOString().substr(11, 8) : "—"}</div>
        <div><b>Notas:</b> {trade.notes ?? "—"}</div>
      </div>

      <a href={`/trades/${trade.id}/edit`} className="inline-block mt-4 px-3 py-2 rounded bg-black text-white">
        Editar
      </a>
    </main>
  );
}

