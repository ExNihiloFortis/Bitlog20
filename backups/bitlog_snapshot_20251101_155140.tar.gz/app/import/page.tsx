// [BLOQUE 1] Componente básico
"use client";
import { useState } from "react";

export default function ImportPage() {
  // [BLOQUE 2] Estado
  const [file, setFile] = useState<File | null>(null);
  const [resumen, setResumen] = useState<string>("");

  // [BLOQUE 3] Handlers
  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;

    const fd = new FormData();
    fd.append("file", file);

    const r = await fetch("/api/import", { method: "POST", body: fd });
    const j = await r.json();
    setResumen(JSON.stringify(j, null, 2));
  }

  // [BLOQUE 4] UI
  return (
    <main className="p-6 max-w-xl mx-auto">
      <h1 className="text-xl font-semibold mb-4">Importar CSV</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <input
          type="file"
          accept=".csv"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="block"
        />
        <button
          type="submit"
          className="px-4 py-2 rounded bg-black text-white disabled:opacity-50"
          disabled={!file}
        >
          Subir y procesar
        </button>
      </form>

      {resumen && (
        <pre className="mt-6 p-3 bg-gray-100 rounded text-sm overflow-auto">
          {resumen}
        </pre>
      )}
    </main>
  );
}

